package com.aiagent.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object ApiClient {
    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun fetchModels(baseUrl: String, apiKey: String): Result<List<String>> =
        withContext(Dispatchers.IO) {
            try {
                val cleanUrl = baseUrl.trimEnd('/')
                val request = Request.Builder()
                    .url("$cleanUrl/models")
                    .addHeader("Authorization", "Bearer $apiKey")
                    .get()
                    .build()

                client.newCall(request).execute().use { response ->
                    val bodyStr = response.body?.string() ?: ""
                    if (!response.isSuccessful) {
                        return@withContext Result.failure(Exception("HTTP ${response.code}: $bodyStr"))
                    }
                    val json = JSONObject(bodyStr)
                    val data = json.optJSONArray("data") ?: JSONArray()
                    val models = mutableListOf<String>()
                    for (i in 0 until data.length()) {
                        val id = data.getJSONObject(i).optString("id")
                        if (id.isNotEmpty()) models.add(id)
                    }
                    Result.success(models.sorted())
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun sendChatCompletion(
        provider: ApiProvider,
        history: List<ChatMessage>
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val cleanUrl = provider.baseUrl.trimEnd('/')
            val messagesArray = JSONArray()

            if (provider.systemPrompt.isNotBlank()) {
                messagesArray.put(JSONObject().apply {
                    put("role", "system")
                    put("content", provider.systemPrompt)
                })
            }

            history.forEach { msg ->
                messagesArray.put(JSONObject().apply {
                    put("role", msg.role)
                    put("content", msg.content)
                })
            }

            val payload = JSONObject().apply {
                put("model", provider.selectedModel)
                put("messages", messagesArray)
                if (provider.reasoningEffort.isNotBlank() && provider.reasoningEffort != "off") {
                    put("reasoning_effort", provider.reasoningEffort)
                }
            }

            val request = Request.Builder()
                .url("$cleanUrl/chat/completions")
                .addHeader("Authorization", "Bearer ${provider.apiKey}")
                .addHeader("Content-Type", "application/json")
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { response ->
                val bodyStr = response.body?.string() ?: ""
                if (!response.isSuccessful) {
                    return@withContext Result.failure(Exception("HTTP ${response.code}: $bodyStr"))
                }
                val json = JSONObject(bodyStr)
                val choices = json.getJSONArray("choices")
                val reply = choices.getJSONObject(0)
                    .getJSONObject("message")
                    .getString("content")
                Result.success(reply)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
