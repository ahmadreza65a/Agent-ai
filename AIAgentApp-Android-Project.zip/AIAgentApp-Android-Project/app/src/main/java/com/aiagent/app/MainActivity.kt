package com.aiagent.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

private val DarkBg = Color(0xFF121214)
private val CardBg = Color(0xFF1E1E22)
private val GoldAccent = Color(0xFFD4AF37)
private val TextPrimary = Color(0xFFF2F2F2)
private val TextSecondary = Color(0xFFA0A0A8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    background = DarkBg,
                    surface = CardBg,
                    primary = GoldAccent,
                    onPrimary = Color.Black,
                    onBackground = TextPrimary,
                    onSurface = TextPrimary
                )
            ) {
                Surface(modifier = Modifier.fillMaxSize(), color = DarkBg) {
                    AgentApp()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AgentApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var providers by remember { mutableStateOf(StorageManager.loadProviders(context)) }
    var activeId by remember { mutableStateOf(StorageManager.loadActiveProviderId(context)) }
    val activeProvider = providers.find { it.id == activeId } ?: providers.first()

    var messages by remember { mutableStateOf(listOf<ChatMessage>()) }
    var inputText by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }

    if (showSettings) {
        SettingsScreen(
            providers = providers,
            activeProvider = activeProvider,
            onSaveProviders = { updatedList, newActiveId ->
                providers = updatedList
                activeId = newActiveId
                StorageManager.saveProviders(context, updatedList)
                StorageManager.saveActiveProviderId(context, newActiveId)
                showSettings = false
            },
            onClose = { showSettings = false }
        )
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(activeProvider.name, fontWeight = FontWeight.Bold, fontSize = 17.sp, color = GoldAccent)
                        Text(
                            "${activeProvider.selectedModel} • Effort: ${activeProvider.reasoningEffort}",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = CardBg),
                actions = {
                    IconButton(onClick = { messages = emptyList() }) {
                        Icon(Icons.Default.Delete, contentDescription = "Clear Chat", tint = TextSecondary)
                    }
                    IconButton(onClick = { showSettings = true }) {
                        Icon(Icons.Default.Settings, contentDescription = "Providers & Models", tint = GoldAccent)
                    }
                }
            )
        },
        bottomBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CardBg)
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("پیام خود را بنویسید...", color = TextSecondary) },
                    maxLines = 4
                )
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(
                    enabled = !isLoading && inputText.isNotBlank(),
                    onClick = {
                        val userMsg = ChatMessage("user", inputText.trim())
                        val updatedHistory = messages + userMsg
                        messages = updatedHistory
                        inputText = ""
                        isLoading = true

                        scope.launch {
                            val result = ApiClient.sendChatCompletion(activeProvider, updatedHistory)
                            isLoading = false
                            result.onSuccess { reply ->
                                messages = messages + ChatMessage("assistant", reply)
                            }.onFailure { err ->
                                messages = messages + ChatMessage("assistant", "خطا در ارتباط:\n${err.message}")
                            }
                        }
                    }
                ) {
                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = GoldAccent)
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(DarkBg)
        ) {
            if (activeProvider.apiKey.isBlank()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF3A2A00))
                        .clickable { showSettings = true }
                        .padding(12.dp)
                ) {
                    Text(
                        "کلید API تنظیم نشده است. برای وارد کردن کلید و انتخاب مدل اینجا لمس کنید.",
                        color = GoldAccent,
                        fontSize = 13.sp
                    )
                }
            }

            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(messages) { msg ->
                    val isUser = msg.role == "user"
                    Box(
                        modifier = Modifier.fillMaxWidth(),
                        contentAlignment = if (isUser) Alignment.CenterEnd else Alignment.CenterStart
                    ) {
                        Surface(
                            color = if (isUser) GoldAccent else CardBg,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.widthIn(max = 310.dp)
                        ) {
                            Text(
                                text = msg.content,
                                color = if (isUser) Color.Black else TextPrimary,
                                modifier = Modifier.padding(12.dp),
                                fontSize = 14.sp
                            )
                        }
                    }
                }
                if (isLoading) {
                    item {
                        CircularProgressIndicator(
                            color = GoldAccent,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(
    providers: List<ApiProvider>,
    activeProvider: ApiProvider,
    onSaveProviders: (List<ApiProvider>, String) -> Unit,
    onClose: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var list by remember { mutableStateOf(providers) }
    var selectedId by remember { mutableStateOf(activeProvider.id) }
    val current = list.find { it.id == selectedId } ?: list.first()

    var name by remember(selectedId) { mutableStateOf(current.name) }
    var baseUrl by remember(selectedId) { mutableStateOf(current.baseUrl) }
    var apiKey by remember(selectedId) { mutableStateOf(current.apiKey) }
    var modelId by remember(selectedId) { mutableStateOf(current.selectedModel) }
    var effort by remember(selectedId) { mutableStateOf(current.reasoningEffort) }
    var sysPrompt by remember(selectedId) { mutableStateOf(current.systemPrompt) }

    var fetchedModels by remember { mutableStateOf<List<String>>(emptyList()) }
    var fetchStatus by remember { mutableStateOf("") }

    val efforts = listOf("off", "none", "low", "medium", "high", "max")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBg)
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("مدیریت پرووایدرها و مدل‌ها", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = GoldAccent)
            TextButton(onClick = onClose) { Text("بستن", color = TextSecondary) }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            list.forEach { p ->
                FilterChip(
                    selected = p.id == selectedId,
                    onClick = { selectedId = p.id },
                    label = { Text(p.name) }
                )
            }
            IconButton(onClick = {
                val newId = "custom_${System.currentTimeMillis()}"
                val newProv = ApiProvider(newId, "Custom API", "https://api.openai.com/v1", "")
                list = list + newProv
                selectedId = newId
            }) {
                Icon(Icons.Default.Add, contentDescription = "Add Provider", tint = GoldAccent)
            }
        }

        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("نام پرووایدر (مثلاً Hormouz)") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = baseUrl, onValueChange = { baseUrl = it }, label = { Text("Base URL (مثلاً https://codeapi.hormouz.net/v1)") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = apiKey, onValueChange = { apiKey = it }, label = { Text("API Key") }, modifier = Modifier.fillMaxWidth())

        Button(
            onClick = {
                fetchStatus = "در حال دریافت لیست مدل‌ها..."
                scope.launch {
                    val res = ApiClient.fetchModels(baseUrl, apiKey)
                    res.onSuccess { models ->
                        fetchedModels = models
                        fetchStatus = "${models.size} مدل دریافت شد. یکی را لمس کنید:"
                    }.onFailure { err ->
                        fetchStatus = "خطا: ${err.message}"
                    }
                }
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = CardBg, contentColor = GoldAccent)
        ) {
            Icon(Icons.Default.Refresh, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Fetch Available Models")
        }

        if (fetchStatus.isNotEmpty()) {
            Text(fetchStatus, fontSize = 12.sp, color = TextSecondary)
        }

        if (fetchedModels.isNotEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 180.dp)
                    .background(CardBg, RoundedCornerShape(8.dp))
                    .verticalScroll(rememberScrollState())
                    .padding(8.dp)
            ) {
                fetchedModels.forEach { m ->
                    Text(
                        text = m,
                        color = if (m == modelId) GoldAccent else TextPrimary,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { modelId = m }
                            .padding(vertical = 6.dp)
                    )
                }
            }
        }

        OutlinedTextField(value = modelId, onValueChange = { modelId = it }, label = { Text("شناسه مدل (Model ID)") }, modifier = Modifier.fillMaxWidth())

        Text("سطح استدلال (Reasoning Effort):", fontSize = 13.sp, color = TextSecondary)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            efforts.forEach { level ->
                FilterChip(
                    selected = effort == level,
                    onClick = { effort = level },
                    label = { Text(level, fontSize = 11.sp) }
                )
            }
        }

        OutlinedTextField(
            value = sysPrompt,
            onValueChange = { sysPrompt = it },
            label = { Text("System Prompt (شخصیت ایجنت)") },
            modifier = Modifier.fillMaxWidth(),
            minLines = 3
        )

        Button(
            onClick = {
                val updated = list.map {
                    if (it.id == selectedId) {
                        it.copy(
                            name = name.trim(),
                            baseUrl = baseUrl.trim(),
                            apiKey = apiKey.trim(),
                            selectedModel = modelId.trim(),
                            reasoningEffort = effort,
                            systemPrompt = sysPrompt.trim()
                        )
                    } else it
                }
                onSaveProviders(updated, selectedId)
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = GoldAccent, contentColor = Color.Black)
        ) {
            Text("ذخیره و فعال‌سازی", fontWeight = FontWeight.Bold)
        }
    }
}
