package com.aiagent.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class ApiProvider(
    val id: String,
    val name: String,
    val baseUrl: String,
    val apiKey: String,
    val selectedModel: String = "deepseek/deepseek-v4-pro",
    val reasoningEffort: String = "medium",
    val systemPrompt: String = "You are a helpful AI agent."
)

data class ChatMessage(
    val role: String, // "user" or "assistant"
    val content: String
)

object StorageManager {
    private const val PREF_NAME = "ai_agent_prefs"
    private const val KEY_PROVIDERS = "providers_json"
    private const val KEY_ACTIVE_ID = "active_provider_id"

    fun saveProviders(context: Context, providers: List<ApiProvider>) {
        val array = JSONArray()
        providers.forEach { p ->
            val obj = JSONObject().apply {
                put("id", p.id)
                put("name", p.name)
                put("baseUrl", p.baseUrl)
                put("apiKey", p.apiKey)
                put("selectedModel", p.selectedModel)
                put("reasoningEffort", p.reasoningEffort)
                put("systemPrompt", p.systemPrompt)
            }
            array.put(obj)
        }
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY_PROVIDERS, array.toString()).apply()
    }

    fun loadProviders(context: Context): List<ApiProvider> {
        val raw = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .getString(KEY_PROVIDERS, null)

        if (raw.isNullOrEmpty()) {
            return listOf(
                ApiProvider(
                    id = "hormouz",
                    name = "Hormouz",
                    baseUrl = "https://codeapi.hormouz.net/v1",
                    apiKey = "",
                    selectedModel = "deepseek/deepseek-v4-pro",
                    reasoningEffort = "medium",
                    systemPrompt = "You are a smart, concise AI assistant."
                )
            )
        }

        val list = mutableListOf<ApiProvider>()
        val array = JSONArray(raw)
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            list.add(
                ApiProvider(
                    id = obj.optString("id", "custom_$i"),
                    name = obj.optString("name", "Custom"),
                    baseUrl = obj.optString("baseUrl", ""),
                    apiKey = obj.optString("apiKey", ""),
                    selectedModel = obj.optString("selectedModel", ""),
                    reasoningEffort = obj.optString("reasoningEffort", "none"),
                    systemPrompt = obj.optString("systemPrompt", "You are a helpful AI agent.")
                )
            )
        }
        return list
    }

    fun saveActiveProviderId(context: Context, id: String) {
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY_ACTIVE_ID, id).apply()
    }

    fun loadActiveProviderId(context: Context): String {
        return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .getString(KEY_ACTIVE_ID, "hormouz") ?: "hormouz"
    }
}
