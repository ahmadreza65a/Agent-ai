# AI Agent Android App (Kotlin + Jetpack Compose)

این پروژه یک اپلیکیشن اندروید ایجنت هوش مصنوعی با پشتیبانی از APIهای سازگار با OpenAI (از جمله سرویس هرمز، OpenRouter، DeepSeek و مدل‌های کاستوم) است.

## نحوه دریافت فایل APK بدون نیاز به Android Studio
1. یک Repository جدید در GitHub بسازید.
2. محتویات این فایل زیپ را اکسترکت کرده و در مخزن گیت‌هاب آپلود (Push) کنید.
3. وارد تب **Actions** در گیت‌هاب شوید و روی آخرین اجرای **Build Android APK** کلیک کنید.
4. پس از اتمام ساخت (حدود ۲ دقیقه)، از بخش **Artifacts** فایل `AI-Agent-APK` را دانلود و فایل `app-debug.apk` داخل آن را روی گوشی نصب کنید.
