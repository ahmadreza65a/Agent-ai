package com.aiagent.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

data class ApiProvider(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val baseUrl: String,
    val apiKey: String,
    val cachedModels: List<String> = emptyList()
)

data class AgentProfile(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val emoji: String = "🤖",
    val providerId: String,
    val modelId: String,
    val reasoningEffort: String = "medium",
    val temperature: Float = 0.7f,
    val systemPrompt: String = "You are a smart, helpful AI assistant. Respond clearly and accurately.",
    val enableStreaming: Boolean = true
)

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val role: String, // "user" or "assistant"
    val content: String,
    val reasoning: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

data class ChatSession(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "گفتگوی جدید",
    val profileId: String,
    val messages: List<ChatMessage> = emptyList(),
    val updatedAt: Long = System.currentTimeMillis()
)

object StorageManager {
    private const val PREF_NAME = "ai_agent_pro_prefs"
    private const val KEY_ACTIVE_PROFILE = "active_profile_id"
    private const val KEY_ACTIVE_SESSION = "active_session_id"

    private const val FILE_PROVIDERS = "providers_v2.json"
    private const val FILE_PROFILES = "profiles_v2.json"
    private const val FILE_SESSIONS = "sessions_v2.json"

    private fun readJsonFile(context: Context, fileName: String): String? {
        return try {
            val file = File(context.filesDir, fileName)
            if (file.exists()) file.readText() else null
        } catch (_: Exception) {
            null
        }
    }

    private fun writeJsonFile(context: Context, fileName: String, content: String) {
        try {
            val file = File(context.filesDir, fileName)
            file.writeText(content)
        } catch (_: Exception) {
        }
    }

    fun saveProviders(context: Context, providers: List<ApiProvider>) {
        val array = JSONArray()
        providers.forEach { p ->
            val modelsArr = JSONArray()
            p.cachedModels.forEach { modelsArr.put(it) }
            array.put(JSONObject().apply {
                put("id", p.id)
                put("name", p.name)
                put("baseUrl", p.baseUrl)
                put("apiKey", p.apiKey)
                put("cachedModels", modelsArr)
            })
        }
        writeJsonFile(context, FILE_PROVIDERS, array.toString())
    }

    fun loadProviders(context: Context): List<ApiProvider> {
        val raw = readJsonFile(context, FILE_PROVIDERS)
        if (raw.isNullOrEmpty()) {
            val defaults = listOf(
                ApiProvider(
                    id = "hormouz",
                    name = "Hormouz",
                    baseUrl = "https://codeapi.hormouz.net/v1",
                    apiKey = "",
                    cachedModels = listOf(
                        "deepseek/deepseek-v4-pro",
                        "deepseek/deepseek-v4.1-flash",
                        "openai/gpt-6-astra",
                        "openai/gpt-6.1-sol",
                        "x-ai/grok-4.7",
                        "z-ai/glm-5.3"
                    )
                ),
                ApiProvider(
                    id = "openrouter",
                    name = "OpenRouter",
                    baseUrl = "https://openrouter.ai/api/v1",
                    apiKey = "",
                    cachedModels = emptyList()
                )
            )
            saveProviders(context, defaults)
            return defaults
        }

        val list = mutableListOf<ApiProvider>()
        val array = JSONArray(raw)
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            val mArr = obj.optJSONArray("cachedModels") ?: JSONArray()
            val models = mutableListOf<String>()
            for (j in 0 until mArr.length()) {
                models.add(mArr.getString(j))
            }
            list.add(
                ApiProvider(
                    id = obj.optString("id", UUID.randomUUID().toString()),
                    name = obj.optString("name", "Custom API"),
                    baseUrl = obj.optString("baseUrl", ""),
                    apiKey = obj.optString("apiKey", ""),
                    cachedModels = models
                )
            )
        }
        return list
    }

    fun saveProfiles(context: Context, profiles: List<AgentProfile>) {
        val array = JSONArray()
        profiles.forEach { p ->
            array.put(JSONObject().apply {
                put("id", p.id)
                put("name", p.name)
                put("emoji", p.emoji)
                put("providerId", p.providerId)
                put("modelId", p.modelId)
                put("reasoningEffort", p.reasoningEffort)
                put("temperature", p.temperature.toDouble())
                put("systemPrompt", p.systemPrompt)
                put("enableStreaming", p.enableStreaming)
            })
        }
        writeJsonFile(context, FILE_PROFILES, array.toString())
    }

    fun loadProfiles(context: Context): List<AgentProfile> {
        val raw = readJsonFile(context, FILE_PROFILES)
        if (raw.isNullOrEmpty()) {
            val defaults = listOf(
                AgentProfile(
                    id = "profile_general",
                    name = "دستیار هوشمند هرمز",
                    emoji = "✨",
                    providerId = "hormouz",
                    modelId = "deepseek/deepseek-v4-pro",
                    reasoningEffort = "medium",
                    temperature = 0.7f,
                    systemPrompt = "تو یک دستیار هوشمند حرفه‌ای و دقیق هستی. به زبان فارسی روان و شفاف پاسخ بده.",
                    enableStreaming = true
                ),
                AgentProfile(
                    id = "profile_coder",
                    name = "برنامه‌نویس ارشد",
                    emoji = "💻",
                    providerId = "hormouz",
                    modelId = "deepseek/deepseek-v4-pro",
                    reasoningEffort = "high",
                    temperature = 0.2f,
                    systemPrompt = "You are a senior software engineer. Write clean, production-ready code with concise Persian explanations.",
                    enableStreaming = true
                ),
                AgentProfile(
                    id = "profile_translator",
                    name = "مترجم حرفه‌ای",
                    emoji = "🌐",
                    providerId = "hormouz",
                    modelId = "deepseek/deepseek-v4.1-flash",
                    reasoningEffort = "low",
                    temperature = 0.3f,
                    systemPrompt = "تو یک مترجم حرفه‌ای هستی. متن کاربر را طبیعی، دقیق و بدون تغییر لحن ترجمه کن.",
                    enableStreaming = true
                )
            )
            saveProfiles(context, defaults)
            return defaults
        }

        val list = mutableListOf<AgentProfile>()
        val array = JSONArray(raw)
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            list.add(
                AgentProfile(
                    id = obj.optString("id", UUID.randomUUID().toString()),
                    name = obj.optString("name", "پروفایل"),
                    emoji = obj.optString("emoji", "🤖"),
                    providerId = obj.optString("providerId", "hormouz"),
                    modelId = obj.optString("modelId", "deepseek/deepseek-v4-pro"),
                    reasoningEffort = obj.optString("reasoningEffort", "medium"),
                    temperature = obj.optDouble("temperature", 0.7).toFloat(),
                    systemPrompt = obj.optString("systemPrompt", "You are a helpful AI assistant."),
                    enableStreaming = obj.optBoolean("enableStreaming", true)
                )
            )
        }
        return list
    }

    fun saveSessions(context: Context, sessions: List<ChatSession>) {
        val array = JSONArray()
        sessions.forEach { s ->
            val msgArr = JSONArray()
            s.messages.forEach { m ->
                msgArr.put(JSONObject().apply {
                    put("id", m.id)
                    put("role", m.role)
                    put("content", m.content)
                    put("reasoning", m.reasoning)
                    put("timestamp", m.timestamp)
                })
            }
            array.put(JSONObject().apply {
                put("id", s.id)
                put("title", s.title)
                put("profileId", s.profileId)
                put("updatedAt", s.updatedAt)
                put("messages", msgArr)
            })
        }
        writeJsonFile(context, FILE_SESSIONS, array.toString())
    }

    fun loadSessions(context: Context, fallbackProfileId: String): List<ChatSession> {
        val raw = readJsonFile(context, FILE_SESSIONS)
        if (raw.isNullOrEmpty()) {
            val first = ChatSession(title = "گفتگوی جدید", profileId = fallbackProfileId)
            return listOf(first)
        }
        val list = mutableListOf<ChatSession>()
        val array = JSONArray(raw)
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            val mArr = obj.optJSONArray("messages") ?: JSONArray()
            val msgs = mutableListOf<ChatMessage>()
            for (j in 0 until mArr.length()) {
                val mObj = mArr.getJSONObject(j)
                msgs.add(
                    ChatMessage(
                        id = mObj.optString("id", UUID.randomUUID().toString()),
                        role = mObj.optString("role", "user"),
                        content = mObj.optString("content", ""),
                        reasoning = mObj.optString("reasoning", ""),
                        timestamp = mObj.optLong("timestamp", System.currentTimeMillis())
                    )
                )
            }
            list.add(
                ChatSession(
                    id = obj.optString("id", UUID.randomUUID().toString()),
                    title = obj.optString("title", "گفتگو"),
                    profileId = obj.optString("profileId", fallbackProfileId),
                    messages = msgs,
                    updatedAt = obj.optLong("updatedAt", System.currentTimeMillis())
                )
            )
        }
        return if (list.isEmpty()) listOf(ChatSession(title = "گفتگوی جدید", profileId = fallbackProfileId)) else list
    }

    fun saveActiveProfileId(context: Context, id: String) {
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY_ACTIVE_PROFILE, id).apply()
    }

    fun loadActiveProfileId(context: Context): String {
        return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .getString(KEY_ACTIVE_PROFILE, "profile_general") ?: "profile_general"
    }

    fun saveActiveSessionId(context: Context, id: String) {
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY_ACTIVE_SESSION, id).apply()
    }

    fun loadActiveSessionId(context: Context): String {
        return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .getString(KEY_ACTIVE_SESSION, "") ?: ""
    }
}
