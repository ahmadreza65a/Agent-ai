package com.aiagent.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

object ApiClient {
    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(180, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun fetchModels(baseUrl: String, apiKey: String): Result<List<String>> =
        withContext(Dispatchers.IO) {
            try {
                val cleanUrl = baseUrl.trimEnd('/')
                val request = Request.Builder()
                    .url("$cleanUrl/models")
                    .addHeader("Authorization", "Bearer $apiKey")
                    .get()
                    .build()

                client.newCall(request).execute().use { response ->
                    val bodyStr = response.body?.string() ?: ""
                    if (!response.isSuccessful) {
                        return@withContext Result.failure(Exception("HTTP ${response.code}: $bodyStr"))
                    }
                    val json = JSONObject(bodyStr)
                    val data = json.optJSONArray("data") ?: JSONArray()
                    val models = mutableListOf<String>()
                    for (i in 0 until data.length()) {
                        val id = data.getJSONObject(i).optString("id")
                        if (id.isNotEmpty()) models.add(id)
                    }
                    Result.success(models.sorted())
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    fun sendChat(
        provider: ApiProvider,
        profile: AgentProfile,
        history: List<ChatMessage>,
        onDelta: (contentDelta: String, reasoningDelta: String) -> Unit,
        onComplete: () -> Unit,
        onError: (String) -> Unit
    ): Call {
        val cleanUrl = provider.baseUrl.trimEnd('/')
        val messagesArray = JSONArray()

        if (profile.systemPrompt.isNotBlank()) {
            messagesArray.put(JSONObject().apply {
                put("role", "system")
                put("content", profile.systemPrompt)
            })
        }

        history.forEach { msg ->
            if (msg.content.isNotBlank()) {
                messagesArray.put(JSONObject().apply {
                    put("role", msg.role)
                    put("content", msg.content)
                })
            }
        }

        val payload = JSONObject().apply {
            put("model", profile.modelId)
            put("messages", messagesArray)
            put("stream", profile.enableStreaming)
            put("temperature", profile.temperature.toDouble())
            if (profile.reasoningEffort.isNotBlank() && profile.reasoningEffort != "off") {
                put("reasoning_effort", profile.reasoningEffort)
            }
        }

        val request = Request.Builder()
            .url("$cleanUrl/chat/completions")
            .addHeader("Authorization", "Bearer ${provider.apiKey}")
            .addHeader("Content-Type", "application/json")
            .post(payload.toString().toRequestBody(jsonMediaType))
            .build()

        val call = client.newCall(request)
        call.enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                if (call.isCanceled()) {
                    onComplete()
                } else {
                    onError("خطای شبکه: ${e.message}")
                }
            }

            override fun onResponse(call: Call, response: Response) {
                response.use { resp ->
                    if (!resp.isSuccessful) {
                        val errBody = resp.body?.string() ?: ""
                        onError("HTTP ${resp.code}: $errBody")
                        return
                    }

                    val body = resp.body
                    if (body == null) {
                        onError("پاسخ خالی از سرور دریافت شد.")
                        return
                    }

                    if (!profile.enableStreaming) {
                        try {
                            val raw = body.string()
                            val json = JSONObject(raw)
                            val msgObj = json.getJSONArray("choices")
                                .getJSONObject(0)
                                .getJSONObject("message")
                            val content = msgObj.optString("content", "")
                            val reasoning = msgObj.optString("reasoning_content",
                                msgObj.optString("reasoning", ""))
                            onDelta(content, reasoning)
                            onComplete()
                        } catch (e: Exception) {
                            onError("خطا در خواندن پاسخ: ${e.message}")
                        }
                        return
                    }

                    try {
                        val reader = body.byteStream().bufferedReader()
                        var line: String?
                        while (reader.readLine().also { line = it } != null) {
                            if (call.isCanceled()) break
                            val trimmed = line?.trim() ?: continue
                            if (!trimmed.startsWith("data:")) continue
                            val dataStr = trimmed.removePrefix("data:").trim()
                            if (dataStr == "[DONE]") break
                            if (dataStr.isEmpty()) continue

                            try {
                                val json = JSONObject(dataStr)
                                val choices = json.optJSONArray("choices") ?: continue
                                if (choices.length() == 0) continue
                                val delta = choices.getJSONObject(0).optJSONObject("delta") ?: continue

                                val contentPart = if (delta.isNull("content")) "" else delta.optString("content", "")
                                val reasoningPart = when {
                                    !delta.isNull("reasoning_content") -> delta.optString("reasoning_content", "")
                                    !delta.isNull("reasoning") -> delta.optString("reasoning", "")
                                    else -> ""
                                }

                                if (contentPart.isNotEmpty() || reasoningPart.isNotEmpty()) {
                                    onDelta(contentPart, reasoningPart)
                                }
                            } catch (_: Exception) {
                                // Ignore malformed keep-alive chunks
                            }
                        }
                        onComplete()
                    } catch (e: Exception) {
                        if (call.isCanceled()) {
                            onComplete()
                        } else {
                            onError("خطا در استریم پاسخ: ${e.message}")
                        }
                    }
                }
            }
        })
        return call
    }
}
