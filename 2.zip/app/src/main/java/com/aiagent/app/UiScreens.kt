package com.aiagent.app

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import java.util.UUID

val DarkBg = Color(0xFF0F0F12)
val CardBg = Color(0xFF1A1A1F)
val ElevatedBg = Color(0xFF24242B)
val GoldAccent = Color(0xFFD4AF37)
val TextPrimary = Color(0xFFF3F3F5)
val TextSecondary = Color(0xFF9E9EA8)
val DangerRed = Color(0xFFE05252)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfilesScreen(
    profiles: List<AgentProfile>,
    providers: List<ApiProvider>,
    activeProfileId: String,
    onSelectProfile: (String) -> Unit,
    onSaveProfiles: (List<AgentProfile>) -> Unit,
    onUpdateProviderModels: (String, List<String>) -> Unit,
    onBack: () -> Unit
) {
    var editingProfile by remember { mutableStateOf<AgentProfile?>(null) }
    var isNewProfile by remember { mutableStateOf(false) }

    if (editingProfile != null) {
        ProfileEditorScreen(
            initialProfile = editingProfile!!,
            providers = providers,
            isNew = isNewProfile,
            onUpdateProviderModels = onUpdateProviderModels,
            onSave = { saved ->
                val updatedList = if (isNewProfile) {
                    profiles + saved
                } else {
                    profiles.map { if (it.id == saved.id) saved else it }
                }
                onSaveProfiles(updatedList)
                if (isNewProfile) onSelectProfile(saved.id)
                editingProfile = null
            },
            onCancel = { editingProfile = null }
        )
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("مدیریت پروفایل‌های ایجنت", color = GoldAccent, fontWeight = FontWeight.Bold, fontSize = 17.sp) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت", tint = TextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = CardBg)
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    val defaultProv = providers.firstOrNull()
                    isNewProfile = true
                    editingProfile = AgentProfile(
                        id = UUID.randomUUID().toString(),
                        name = "پروفایل جدید",
                        emoji = "🤖",
                        providerId = defaultProv?.id ?: "hormouz",
                        modelId = defaultProv?.cachedModels?.firstOrNull() ?: "deepseek/deepseek-v4-pro",
                        reasoningEffort = "medium",
                        temperature = 0.7f,
                        systemPrompt = "You are a helpful AI assistant.",
                        enableStreaming = true
                    )
                },
                containerColor = GoldAccent,
                contentColor = Color.Black
            ) {
                Icon(Icons.Default.Add, contentDescription = "افزودن پروفایل")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(DarkBg)
                .padding(padding)
                .padding(14.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            profiles.forEach { profile ->
                val providerName = providers.find { it.id == profile.providerId }?.name ?: "نامشخص"
                val isActive = profile.id == activeProfileId

                Surface(
                    color = if (isActive) Color(0xFF262216) else CardBg,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            onSelectProfile(profile.id)
                            onBack()
                        }
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(profile.emoji, fontSize = 22.sp)
                                Spacer(Modifier.width(10.dp))
                                Column {
                                    Text(
                                        profile.name,
                                        color = if (isActive) GoldAccent else TextPrimary,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp
                                    )
                                    Text(
                                        "$providerName • ${profile.modelId}",
                                        color = TextSecondary,
                                        fontSize = 12.sp
                                    )
                                }
                            }
                            Row {
                                IconButton(onClick = {
                                    isNewProfile = false
                                    editingProfile = profile
                                }) {
                                    Icon(Icons.Default.Edit, contentDescription = "ویرایش", tint = GoldAccent)
                                }
                                IconButton(onClick = {
                                    val copy = profile.copy(
                                        id = UUID.randomUUID().toString(),
                                        name = "${profile.name} (کپی)"
                                    )
                                    onSaveProfiles(profiles + copy)
                                }) {
                                    Icon(Icons.Default.ContentCopy, contentDescription = "کپی", tint = TextSecondary)
                                }
                                if (profiles.size > 1) {
                                    IconButton(onClick = {
                                        val remaining = profiles.filter { it.id != profile.id }
                                        onSaveProfiles(remaining)
                                        if (isActive && remaining.isNotEmpty()) {
                                            onSelectProfile(remaining.first().id)
                                        }
                                    }) {
                                        Icon(Icons.Default.Delete, contentDescription = "حذف", tint = DangerRed)
                                    }
                                }
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "Effort: ${profile.reasoningEffort} | Temp: ${"%.1f".format(profile.temperature)} | Stream: ${if (profile.enableStreaming) "ON" else "OFF"}",
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }
            }
            Spacer(Modifier.height(70.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileEditorScreen(
    initialProfile: AgentProfile,
    providers: List<ApiProvider>,
    isNew: Boolean,
    onUpdateProviderModels: (String, List<String>) -> Unit,
    onSave: (AgentProfile) -> Unit,
    onCancel: () -> Unit
) {
    val scope = rememberCoroutineScope()

    var name by remember { mutableStateOf(initialProfile.name) }
    var emoji by remember { mutableStateOf(initialProfile.emoji) }
    var providerId by remember { mutableStateOf(initialProfile.providerId) }
    var modelId by remember { mutableStateOf(initialProfile.modelId) }
    var effort by remember { mutableStateOf(initialProfile.reasoningEffort) }
    var temperature by remember { mutableStateOf(initialProfile.temperature) }
    var systemPrompt by remember { mutableStateOf(initialProfile.systemPrompt) }
    var enableStreaming by remember { mutableStateOf(initialProfile.enableStreaming) }

    val selectedProvider = providers.find { it.id == providerId } ?: providers.firstOrNull()
    var availableModels by remember(providerId) { mutableStateOf(selectedProvider?.cachedModels ?: emptyList()) }
    var modelSearch by remember { mutableStateOf("") }
    var fetchStatus by remember { mutableStateOf("") }
    var isFetching by remember { mutableStateOf(false) }

    val emojis = listOf("🤖", "✨", "💻", "🌐", "📊", "✍️", "🧠", "⚡", "🎯", "🛡️")
    val efforts = listOf("off", "none", "low", "medium", "high", "max")

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (isNew) "ساخت پروفایل جدید" else "ویرایش پروفایل", color = GoldAccent, fontWeight = FontWeight.Bold, fontSize = 17.sp) },
                navigationIcon = {
                    IconButton(onClick = onCancel) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "انصراف", tint = TextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = CardBg)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(DarkBg)
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("آیکون پروفایل:", color = TextSecondary, fontSize = 12.sp)
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                emojis.forEach { e ->
                    FilterChip(
                        selected = emoji == e,
                        onClick = { emoji = e },
                        label = { Text(e, fontSize = 18.sp) }
                    )
                }
            }

            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("نام پروفایل (مثلاً برنامه‌نویس هرمز)") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            Text("انتخاب ارائه‌دهنده (API Provider):", color = TextSecondary, fontSize = 12.sp)
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                providers.forEach { p ->
                    FilterChip(
                        selected = providerId == p.id,
                        onClick = {
                            providerId = p.id
                            availableModels = p.cachedModels
                        },
                        label = { Text(p.name) }
                    )
                }
            }

            Button(
                enabled = !isFetching && selectedProvider != null,
                onClick = {
                    if (selectedProvider == null) return@Button
                    isFetching = true
                    fetchStatus = "در حال دریافت لیست مدل‌ها..."
                    scope.launch {
                        val res = ApiClient.fetchModels(selectedProvider.baseUrl, selectedProvider.apiKey)
                        isFetching = false
                        res.onSuccess { list ->
                            availableModels = list
                            onUpdateProviderModels(selectedProvider.id, list)
                            fetchStatus = "${list.size} مدل دریافت شد."
                        }.onFailure { err ->
                            fetchStatus = "خطا: ${err.message}"
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = ElevatedBg, contentColor = GoldAccent)
            ) {
                Icon(Icons.Default.Refresh, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Fetch Available Models")
            }

            if (fetchStatus.isNotEmpty()) {
                Text(fetchStatus, fontSize = 12.sp, color = TextSecondary)
            }

            if (availableModels.isNotEmpty()) {
                OutlinedTextField(
                    value = modelSearch,
                    onValueChange = { modelSearch = it },
                    label = { Text("جستجو در مدل‌های دریافت‌شده...") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                val filtered = availableModels.filter {
                    modelSearch.isBlank() || it.contains(modelSearch, ignoreCase = true)
                }
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 160.dp)
                        .background(CardBg, RoundedCornerShape(10.dp))
                        .verticalScroll(rememberScrollState())
                        .padding(8.dp)
                ) {
                    filtered.forEach { m ->
                        Text(
                            text = m,
                            color = if (m == modelId) GoldAccent else TextPrimary,
                            fontWeight = if (m == modelId) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 13.sp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { modelId = m }
                                .padding(vertical = 6.dp, horizontal = 4.dp)
                        )
                    }
                }
            }

            OutlinedTextField(
                value = modelId,
                onValueChange = { modelId = it },
                label = { Text("شناسه مدل (Model ID)") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            Text("سطح استدلال (Reasoning Effort):", color = TextSecondary, fontSize = 12.sp)
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                efforts.forEach { lvl ->
                    FilterChip(
                        selected = effort == lvl,
                        onClick = { effort = lvl },
                        label = { Text(lvl, fontSize = 12.sp) }
                    )
                }
            }

            Column {
                Text("خلاقیت مدل (Temperature): ${"%.1f".format(temperature)}", color = TextSecondary, fontSize = 12.sp)
                Slider(
                    value = temperature,
                    onValueChange = { temperature = it },
                    valueRange = 0f..1.5f,
                    steps = 14,
                    colors = SliderDefaults.colors(thumbColor = GoldAccent, activeTrackColor = GoldAccent)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("پاسخ‌دهی زنده (Streaming)", color = TextPrimary, fontSize = 14.sp)
                    Text("نمایش کلمه‌به‌کلمه پاسخ به صورت آنی", color = TextSecondary, fontSize = 11.sp)
                }
                Switch(
                    checked = enableStreaming,
                    onCheckedChange = { enableStreaming = it },
                    colors = SwitchDefaults.colors(checkedThumbColor = Color.Black, checkedTrackColor = GoldAccent)
                )
            }

            OutlinedTextField(
                value = systemPrompt,
                onValueChange = { systemPrompt = it },
                label = { Text("System Prompt (دستورالعمل و شخصیت ایجنت)") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 4
            )

            Button(
                onClick = {
                    onSave(
                        initialProfile.copy(
                            name = name.trim().ifEmpty { "پروفایل" },
                            emoji = emoji,
                            providerId = providerId,
                            modelId = modelId.trim(),
                            reasoningEffort = effort,
                            temperature = temperature,
                            systemPrompt = systemPrompt.trim(),
                            enableStreaming = enableStreaming
                        )
                    )
                },
                modifier = Modifier.fillMaxWidth().height(50.dp),
                colors = ButtonDefaults.buttonColors(containerColor = GoldAccent, contentColor = Color.Black)
            ) {
                Text("ذخیره پروفایل", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProvidersScreen(
    providers: List<ApiProvider>,
    onSaveProviders: (List<ApiProvider>) -> Unit,
    onBack: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var list by remember { mutableStateOf(providers) }
    var selectedId by remember { mutableStateOf(providers.firstOrNull()?.id ?: "") }
    val current = list.find { it.id == selectedId } ?: list.first()

    var name by remember(selectedId) { mutableStateOf(current.name) }
    var baseUrl by remember(selectedId) { mutableStateOf(current.baseUrl) }
    var apiKey by remember(selectedId) { mutableStateOf(current.apiKey) }
    var testStatus by remember(selectedId) { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("مدیریت ارائه‌دهنده‌های API", color = GoldAccent, fontWeight = FontWeight.Bold, fontSize = 17.sp) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت", tint = TextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = CardBg)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(DarkBg)
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                list.forEach { p ->
                    FilterChip(
                        selected = p.id == selectedId,
                        onClick = { selectedId = p.id },
                        label = { Text(p.name) }
                    )
                }
                IconButton(onClick = {
                    val newProv = ApiProvider(
                        id = UUID.randomUUID().toString(),
                        name = "Custom API",
                        baseUrl = "https://api.openai.com/v1",
                        apiKey = ""
                    )
                    list = list + newProv
                    selectedId = newProv.id
                }) {
                    Icon(Icons.Default.Add, contentDescription = "افزودن ارائه‌دهنده", tint = GoldAccent)
                }
            }

            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("نام ارائه‌دهنده (مثلاً Hormouz)") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            OutlinedTextField(
                value = baseUrl,
                onValueChange = { baseUrl = it },
                label = { Text("Base URL (مثلاً https://codeapi.hormouz.net/v1)") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            OutlinedTextField(
                value = apiKey,
                onValueChange = { apiKey = it },
                label = { Text("API Key") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            Button(
                onClick = {
                    testStatus = "در حال تست اتصال و دریافت مدل‌ها..."
                    scope.launch {
                        val res = ApiClient.fetchModels(baseUrl.trim(), apiKey.trim())
                        res.onSuccess { models ->
                            list = list.map {
                                if (it.id == selectedId) {
                                    it.copy(
                                        name = name.trim(),
                                        baseUrl = baseUrl.trim(),
                                        apiKey = apiKey.trim(),
                                        cachedModels = models
                                    )
                                } else it
                            }
                            onSaveProviders(list)
                            testStatus = "اتصال موفق! ${models.size} مدل ذخیره شد."
                        }.onFailure { err ->
                            testStatus = "خطا: ${err.message}"
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = ElevatedBg, contentColor = GoldAccent)
            ) {
                Icon(Icons.Default.CheckCircle, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("تست اتصال و ذخیره لیست مدل‌ها")
            }

            if (testStatus.isNotEmpty()) {
                Text(testStatus, fontSize = 12.sp, color = TextSecondary)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                Button(
                    onClick = {
                        val updated = list.map {
                            if (it.id == selectedId) {
                                it.copy(
                                    name = name.trim().ifEmpty { "Custom" },
                                    baseUrl = baseUrl.trim(),
                                    apiKey = apiKey.trim()
                                )
                            } else it
                        }
                        list = updated
                        onSaveProviders(updated)
                        testStatus = "تنظیمات ذخیره شد."
                    },
                    modifier = Modifier.weight(1f).height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = GoldAccent, contentColor = Color.Black)
                ) {
                    Text("ذخیره تغییرات", fontWeight = FontWeight.Bold)
                }

                if (list.size > 1) {
                    OutlinedButton(
                        onClick = {
                            val remaining = list.filter { it.id != selectedId }
                            list = remaining
                            selectedId = remaining.first().id
                            onSaveProviders(remaining)
                        },
                        modifier = Modifier.height(48.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = DangerRed)
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = "حذف")
                    }
                }
            }
        }
    }
}
