package com.aiagent.app

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.Call
import java.util.UUID

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    background = DarkBg,
                    surface = CardBg,
                    primary = GoldAccent,
                    onPrimary = Color.Black,
                    onBackground = TextPrimary,
                    onSurface = TextPrimary
                )
            ) {
                Surface(modifier = Modifier.fillMaxSize(), color = DarkBg) {
                    AgentProApp()
                }
            }
        }
    }
}

enum class ScreenRoute { CHAT, PROFILES, PROVIDERS }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AgentProApp() {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val listState = rememberLazyListState()

    var currentRoute by remember { mutableStateOf(ScreenRoute.CHAT) }
    var providers by remember { mutableStateOf(StorageManager.loadProviders(context)) }
    var profiles by remember { mutableStateOf(StorageManager.loadProfiles(context)) }
    var activeProfileId by remember { mutableStateOf(StorageManager.loadActiveProfileId(context)) }

    val activeProfile = profiles.find { it.id == activeProfileId } ?: profiles.first()
    val activeProvider = providers.find { it.id == activeProfile.providerId } ?: providers.first()

    var sessions by remember { mutableStateOf(StorageManager.loadSessions(context, activeProfile.id)) }
    var activeSessionId by remember {
        val saved = StorageManager.loadActiveSessionId(context)
        mutableStateOf(if (sessions.any { it.id == saved }) saved else sessions.first().id)
    }
    val activeSession = sessions.find { it.id == activeSessionId } ?: sessions.first()

    var inputText by remember { mutableStateOf("") }
    var isStreaming by remember { mutableStateOf(false) }
    var activeCall by remember { mutableStateOf<Call?>(null) }
    var showProfileMenu by remember { mutableStateOf(false) }

    fun updateSessions(newList: List<ChatSession>) {
        sessions = newList
        StorageManager.saveSessions(context, newList)
    }

    fun startNewChat() {
        val newSess = ChatSession(
            id = UUID.randomUUID().toString(),
            title = "گفتگوی جدید",
            profileId = activeProfile.id
        )
        val updated = listOf(newSess) + sessions
        updateSessions(updated)
        activeSessionId = newSess.id
        StorageManager.saveActiveSessionId(context, newSess.id)
    }

    fun sendMessage(text: String, regenerate: Boolean = false) {
        if (activeProvider.apiKey.isBlank()) {
            Toast.makeText(context, "ابتدا کلید API را در بخش ارائه‌دهنده‌ها وارد کنید.", Toast.LENGTH_LONG).show()
            currentRoute = ScreenRoute.PROVIDERS
            return
        }

        val currentMsgs = if (regenerate) {
            activeSession.messages.dropLastWhile { it.role == "assistant" }
        } else {
            activeSession.messages + ChatMessage(role = "user", content = text.trim())
        }

        if (currentMsgs.isEmpty()) return

        val assistantId = UUID.randomUUID().toString()
        val placeholder = ChatMessage(id = assistantId, role = "assistant", content = "")
        val newTitle = if (activeSession.messages.isEmpty() && !regenerate) {
            text.trim().take(32)
        } else {
            activeSession.title
        }

        val sessionWithPlaceholder = activeSession.copy(
            title = newTitle,
            profileId = activeProfile.id,
            messages = currentMsgs + placeholder,
            updatedAt = System.currentTimeMillis()
        )
        updateSessions(sessions.map { if (it.id == activeSession.id) sessionWithPlaceholder else it })
        if (!regenerate) inputText = ""
        isStreaming = true

        val contentBuf = StringBuilder()
        val reasoningBuf = StringBuilder()

        activeCall = ApiClient.sendChat(
            provider = activeProvider,
            profile = activeProfile,
            history = currentMsgs,
            onDelta = { cDelta, rDelta ->
                contentBuf.append(cDelta)
                reasoningBuf.append(rDelta)
                val newContent = contentBuf.toString()
                val newReasoning = reasoningBuf.toString()
                scope.launch(Dispatchers.Main) {
                    sessions = sessions.map { s ->
                        if (s.id == activeSession.id) {
                            s.copy(messages = s.messages.map { m ->
                                if (m.id == assistantId) m.copy(content = newContent, reasoning = newReasoning) else m
                            })
                        } else s
                    }
                }
            },
            onComplete = {
                scope.launch(Dispatchers.Main) {
                    isStreaming = false
                    activeCall = null
                    StorageManager.saveSessions(context, sessions)
                }
            },
            onError = { errMsg ->
                scope.launch(Dispatchers.Main) {
                    isStreaming = false
                    activeCall = null
                    sessions = sessions.map { s ->
                        if (s.id == activeSession.id) {
                            s.copy(messages = s.messages.map { m ->
                                if (m.id == assistantId) m.copy(content = "خطا در ارتباط:\n$errMsg") else m
                            })
                        } else s
                    }
                    StorageManager.saveSessions(context, sessions)
                }
            }
        )
    }

    LaunchedEffect(activeSession.messages.size, activeSession.messages.lastOrNull()?.content?.length) {
        if (activeSession.messages.isNotEmpty()) {
            listState.animateScrollToItem(activeSession.messages.size - 1)
        }
    }

    when (currentRoute) {
        ScreenRoute.PROFILES -> {
            ProfilesScreen(
                profiles = profiles,
                providers = providers,
                activeProfileId = activeProfile.id,
                onSelectProfile = { newId ->
                    activeProfileId = newId
                    StorageManager.saveActiveProfileId(context, newId)
                },
                onSaveProfiles = { updated ->
                    profiles = updated
                    StorageManager.saveProfiles(context, updated)
                },
                onUpdateProviderModels = { provId, models ->
                    val updated = providers.map { if (it.id == provId) it.copy(cachedModels = models) else it }
                    providers = updated
                    StorageManager.saveProviders(context, updated)
                },
                onBack = { currentRoute = ScreenRoute.CHAT }
            )
            return
        }
        ScreenRoute.PROVIDERS -> {
            ProvidersScreen(
                providers = providers,
                onSaveProviders = { updated ->
                    providers = updated
                    StorageManager.saveProviders(context, updated)
                },
                onBack = { currentRoute = ScreenRoute.CHAT }
            )
            return
        }
        ScreenRoute.CHAT -> Unit
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = CardBg,
                modifier = Modifier.width(290.dp)
            ) {
                Column(modifier = Modifier.fillMaxSize().padding(14.dp)) {
                    Text("AI Agent Pro", color = GoldAccent, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("نسخه ۲.۰ • مدیریت پروفایل و چت", color = TextSecondary, fontSize = 11.sp)
                    Spacer(Modifier.height(14.dp))

                    Button(
                        onClick = {
                            startNewChat()
                            scope.launch { drawerState.close() }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = GoldAccent, contentColor = Color.Black)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("گفتگوی جدید", fontWeight = FontWeight.Bold)
                    }

                    Spacer(Modifier.height(10.dp))

                    NavigationDrawerItem(
                        label = { Text("پروفایل‌های ایجنت (${profiles.size})", color = TextPrimary) },
                        icon = { Icon(Icons.Default.Person, contentDescription = null, tint = GoldAccent) },
                        selected = false,
                        onClick = {
                            scope.launch { drawerState.close() }
                            currentRoute = ScreenRoute.PROFILES
                        }
                    )

                    NavigationDrawerItem(
                        label = { Text("ارائه‌دهنده‌های API (${providers.size})", color = TextPrimary) },
                        icon = { Icon(Icons.Default.Key, contentDescription = null, tint = GoldAccent) },
                        selected = false,
                        onClick = {
                            scope.launch { drawerState.close() }
                            currentRoute = ScreenRoute.PROVIDERS
                        }
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = ElevatedBg)
                    Text("تاریخچه مکالمات", color = TextSecondary, fontSize = 12.sp, modifier = Modifier.padding(bottom = 6.dp))

                    LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        itemsIndexed(sessions) { _, sess ->
                            val isSelected = sess.id == activeSession.id
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(if (isSelected) ElevatedBg else Color.Transparent, RoundedCornerShape(10.dp))
                                    .clickable {
                                        activeSessionId = sess.id
                                        StorageManager.saveActiveSessionId(context, sess.id)
                                        scope.launch { drawerState.close() }
                                    }
                                    .padding(horizontal = 10.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = sess.title,
                                    color = if (isSelected) GoldAccent else TextPrimary,
                                    fontSize = 13.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                                if (sessions.size > 1) {
                                    IconButton(
                                        onClick = {
                                            val remaining = sessions.filter { it.id != sess.id }
                                            updateSessions(remaining)
                                            if (isSelected) {
                                                activeSessionId = remaining.first().id
                                                StorageManager.saveActiveSessionId(context, remaining.first().id)
                                            }
                                        },
                                        modifier = Modifier.size(26.dp)
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = "حذف", tint = TextSecondary, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Default.Menu, contentDescription = "منو", tint = GoldAccent)
                        }
                    },
                    title = {
                        Box {
                            Column(modifier = Modifier.clickable { showProfileMenu = true }) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("${activeProfile.emoji} ${activeProfile.name}", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = GoldAccent, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = GoldAccent)
                                }
                                Text(
                                    "${activeProfile.modelId} • ${activeProfile.reasoningEffort}",
                                    fontSize = 11.sp,
                                    color = TextSecondary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            DropdownMenu(
                                expanded = showProfileMenu,
                                onDismissRequest = { showProfileMenu = false },
                                modifier = Modifier.background(ElevatedBg)
                            ) {
                                profiles.forEach { p ->
                                    DropdownMenuItem(
                                        text = {
                                            Text(
                                                "${p.emoji} ${p.name}",
                                                color = if (p.id == activeProfile.id) GoldAccent else TextPrimary,
                                                fontWeight = if (p.id == activeProfile.id) FontWeight.Bold else FontWeight.Normal
                                            )
                                        },
                                        onClick = {
                                            activeProfileId = p.id
                                            StorageManager.saveActiveProfileId(context, p.id)
                                            showProfileMenu = false
                                        }
                                    )
                                }
                                HorizontalDivider(color = CardBg)
                                DropdownMenuItem(
                                    text = { Text("+ مدیریت و ساخت پروفایل", color = GoldAccent) },
                                    onClick = {
                                        showProfileMenu = false
                                        currentRoute = ScreenRoute.PROFILES
                                    }
                                )
                            }
                        }
                    },
                    actions = {
                        IconButton(onClick = { startNewChat() }) {
                            Icon(Icons.Default.AddComment, contentDescription = "چت جدید", tint = TextSecondary)
                        }
                        IconButton(onClick = { currentRoute = ScreenRoute.PROVIDERS }) {
                            Icon(Icons.Default.Settings, contentDescription = "تنظیمات API", tint = GoldAccent)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = CardBg)
                )
            },
            bottomBar = {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CardBg)
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = inputText,
                        onValueChange = { inputText = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("پیام خود را بنویسید...", color = TextSecondary) },
                        maxLines = 5
                    )
                    Spacer(Modifier.width(8.dp))
                    if (isStreaming) {
                        IconButton(
                            onClick = {
                                activeCall?.cancel()
                                isStreaming = false
                            }
                        ) {
                            Icon(Icons.Default.StopCircle, contentDescription = "توقف", tint = DangerRed, modifier = Modifier.size(32.dp))
                        }
                    } else {
                        IconButton(
                            enabled = inputText.isNotBlank(),
                            onClick = { sendMessage(inputText) }
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "ارسال", tint = GoldAccent)
                        }
                    }
                }
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .background(DarkBg)
            ) {
                if (activeProvider.apiKey.isBlank()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF3A2A00))
                            .clickable { currentRoute = ScreenRoute.PROVIDERS }
                            .padding(12.dp)
                    ) {
                        Text(
                            "کلید API برای «${activeProvider.name}» ثبت نشده است. برای تنظیم اینجا لمس کنید.",
                            color = GoldAccent,
                            fontSize = 13.sp
                        )
                    }
                }

                if (activeSession.messages.isEmpty()) {
                    Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(24.dp)) {
                            Text(activeProfile.emoji, fontSize = 48.sp)
                            Spacer(Modifier.height(10.dp))
                            Text(activeProfile.name, color = GoldAccent, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(6.dp))
                            Text(
                                "مدل فعال: ${activeProfile.modelId}",
                                color = TextSecondary,
                                fontSize = 13.sp
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        itemsIndexed(activeSession.messages) { index, msg ->
                            val isUser = msg.role == "user"
                            val isLast = index == activeSession.messages.lastIndex
                            MessageBubble(
                                msg = msg,
                                isUser = isUser,
                                showRegenerate = !isUser && isLast && !isStreaming,
                                onCopy = {
                                    clipboard.setText(AnnotatedString(msg.content))
                                    Toast.makeText(context, "متن کپی شد", Toast.LENGTH_SHORT).show()
                                },
                                onRegenerate = { sendMessage("", regenerate = true) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MessageBubble(
    msg: ChatMessage,
    isUser: Boolean,
    showRegenerate: Boolean,
    onCopy: () -> Unit,
    onRegenerate: () -> Unit
) {
    var showReasoning by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        Surface(
            color = if (isUser) GoldAccent else CardBg,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.widthIn(max = 330.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                if (!isUser && msg.reasoning.isNotBlank()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(ElevatedBg, RoundedCornerShape(8.dp))
                            .clickable { showReasoning = !showReasoning }
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("🧠 فرایند استدلال مدل", color = GoldAccent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Icon(
                            if (showReasoning) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = null,
                            tint = GoldAccent,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    if (showReasoning) {
                        Text(
                            text = msg.reasoning,
                            color = TextSecondary,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(top = 6.dp, bottom = 8.dp)
                        )
                    } else {
                        Spacer(Modifier.height(6.dp))
                    }
                }

                Text(
                    text = if (msg.content.isEmpty() && !isUser) "در حال تفکر..." else msg.content,
                    color = if (isUser) Color.Black else TextPrimary,
                    fontSize = 14.sp
                )
            }
        }

        if (msg.content.isNotBlank()) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                modifier = Modifier.padding(top = 2.dp, start = 4.dp, end = 4.dp)
            ) {
                IconButton(onClick = onCopy, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.ContentCopy, contentDescription = "کپی", tint = TextSecondary, modifier = Modifier.size(15.dp))
                }
                if (showRegenerate) {
                    IconButton(onClick = onRegenerate, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Refresh, contentDescription = "تولید مجدد", tint = TextSecondary, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}
